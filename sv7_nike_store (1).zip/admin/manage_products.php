<?php
include('../includes/db.php');
session_start();
if(!isset($_SESSION['admin_id'])) header('Location: login.php');
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['action'])){
  if($_POST['action']=='add'){
    $n=$conn->real_escape_string($_POST['name']);
    $p=intval($_POST['price']);
    $img=$conn->real_escape_string($_POST['image']);
    $conn->query("INSERT INTO products (name,price,image) VALUES ('$n',$p,'$img')");
  } elseif($_POST['action']=='delete'){
    $id=intval($_POST['id']);
    $conn->query("DELETE FROM products WHERE id=$id");
  }
}
$res=$conn->query('SELECT * FROM products');
?>
<!doctype html><html><head><meta charset='utf-8'><title>Manage Products</title></head><body>
<h2>Quản lý sản phẩm</h2>
<form method='POST'>
  <input name='name' placeholder='Tên'><input name='price' placeholder='Giá'><input name='image' placeholder='URL ảnh'>
  <input type='hidden' name='action' value='add'><button type='submit'>Thêm</button>
</form>
<table border='1'><tr><th>ID</th><th>Tên</th><th>Giá</th><th>Ảnh</th><th>Hành động</th></tr>
<?php while($r=$res->fetch_assoc()){ echo "<tr><td>{$r['id']}</td><td>{$r['name']}</td><td>".number_format($r['price'])."</td><td>{$r['image']}</td><td>
<form method='POST' style='display:inline'><input type='hidden' name='action' value='delete'><input type='hidden' name='id' value='{$r['id']}'><button>Delete</button></form>
</td></tr>"; } ?>
</table>
</body></html>
