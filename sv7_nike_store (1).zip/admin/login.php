<?php
include('../includes/db.php');
session_start();
if($_SERVER['REQUEST_METHOD']=='POST'){
  $email = $conn->real_escape_string($_POST['email']);
  $res = $conn->query("SELECT * FROM users WHERE email='$email' AND is_admin=1");
  if($res && $res->num_rows){
    $user = $res->fetch_assoc();
    if(password_verify($_POST['password'], $user['password'])){
      $_SESSION['admin_id'] = $user['id'];
      header('Location: index.php'); exit;
    } else $err='Sai mật khẩu';
  } else $err='Không tìm thấy admin';
}
?>
<!doctype html><html><head><meta charset='utf-8'><title>Admin Login</title></head><body>
<h2>Admin Login</h2>
<?php if(isset($err)) echo '<p style="color:red">'.$err.'</p>'; ?>
<form method='POST'>
  <label>Email</label><input type='email' name='email' required><br>
  <label>Password</label><input type='password' name='password' required><br>
  <button type='submit'>Login</button>
</form>
</body></html>
