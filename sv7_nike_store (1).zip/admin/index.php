<?php
include('../includes/db.php');
session_start();
if(!isset($_SESSION['admin_id'])) header('Location: login.php');
?>
<!doctype html><html><head><meta charset='utf-8'><title>Admin</title></head><body>
<h2>Admin Dashboard</h2>
<ul>
  <li><a href='manage_products.php'>Quản lý sản phẩm</a></li>
  <li><a href='manage_orders.php'>Quản lý đơn hàng</a></li>
</ul>
</body></html>
