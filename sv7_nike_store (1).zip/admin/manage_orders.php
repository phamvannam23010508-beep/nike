<?php
include('../includes/db.php');
session_start();
if(!isset($_SESSION['admin_id'])) header('Location: login.php');
if(isset($_GET['accept'])){
  $id=intval($_GET['accept']);
  $conn->query("UPDATE orders SET status='Đã duyệt' WHERE id=$id");
}
$res = $conn->query("SELECT o.*, u.name, u.email, u.phone FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC");
?>
<!doctype html><html><head><meta charset='utf-8'><title>Manage Orders</title></head><body>
<h2>Danh sách đơn hàng</h2>
<table border='1'><tr><th>ID</th><th>Khách</th><th>Email</th><th>Phone</th><th>Địa chỉ</th><th>Tổng</th><th>Trạng thái</th><th>Hành động</th></tr>
<?php while($r=$res->fetch_assoc()){ echo "<tr><td>{$r['id']}</td><td>{$r['name']}</td><td>{$r['email']}</td><td>{$r['phone']}</td><td>{$r['address']}</td><td>".number_format($r['total_price'])."</td><td>{$r['status']}</td><td><a href='?accept={$r['id']}'>Duyệt</a></td></tr>"; } ?>
</table>
</body></html>
