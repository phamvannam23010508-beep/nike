-- Database schema for SV7 Nike Store
CREATE DATABASE IF NOT EXISTS nike_store;
USE nike_store;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255),
  phone VARCHAR(20),
  address TEXT,
  is_admin TINYINT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  price INT,
  image VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  total_price INT,
  address TEXT,
  phone VARCHAR(20),
  email VARCHAR(100),
  payment_method VARCHAR(50),
  status VARCHAR(50) DEFAULT 'Đang xử lý',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT,
  product_id INT,
  quantity INT,
  price INT,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- Sample admin user (password: admin123) - use password_hash in production
INSERT IGNORE INTO users (name, email, password, is_admin) VALUES
('Administrator','admin@sv7.local', SHA2('admin123',256), 1);

-- Sample products
INSERT IGNORE INTO products (name, price, image) VALUES
('Nike Air Max', 3200000, 'https://your-bucket.s3.amazonaws.com/nike1.jpg'),
('Air Jordan 1', 4500000, 'https://your-bucket.s3.amazonaws.com/nike2.jpg'),
('Nike ZoomX', 3900000, 'https://your-bucket.s3.amazonaws.com/nike3.jpg');
