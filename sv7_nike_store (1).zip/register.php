<?php
include('includes/db.php');
if($_SERVER['REQUEST_METHOD']=='POST'){
  $name = $conn->real_escape_string($_POST['name']);
  $email = $conn->real_escape_string($_POST['email']);
  $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
  $phone = $conn->real_escape_string($_POST['phone']);
  $address = $conn->real_escape_string($_POST['address']);
  $conn->query("INSERT INTO users (name,email,password,phone,address) VALUES ('$name','$email','$pass','$phone','$address')");
  header('Location: login.php');
  exit;
}
?>
<!doctype html><html><head><meta charset='utf-8'><title>Register</title></head><body>
<h2>Đăng ký</h2>
<form method='POST'>
  <label>Họ tên</label><br><input name='name' required><br>
  <label>Email</label><br><input name='email' type='email' required><br>
  <label>Mật khẩu</label><br><input name='password' type='password' required><br>
  <label>Phone</label><br><input name='phone'><br>
  <label>Địa chỉ</label><br><textarea name='address'></textarea><br>
  <button type='submit'>Đăng ký</button>
</form>
</body></html>
