<?php
session_start();
include('includes/db.php');

if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['product_id'])){
  $id = intval($_POST['product_id']);
  $qty = isset($_POST['qty']) ? intval($_POST['qty']) : 1;
  $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + $qty;
  header('Location: cart.php');
  exit;
}

include('includes/header.php');
?>
<!doctype html><html><head><meta charset='utf-8'><title>Giỏ hàng</title><link rel='stylesheet' href='style.css'></head><body>
<section class='cart-section'>
<h2>Giỏ hàng của bạn</h2>
<?php
$cart = $_SESSION['cart'] ?? [];
if(empty($cart)) { echo '<p>Giỏ hàng trống</p>'; exit; }
$ids = implode(',', array_keys($cart));
$res = $conn->query("SELECT * FROM products WHERE id IN ($ids)");
$total=0;
echo "<form method='POST' action='checkout.php'>";
while($r = $res->fetch_assoc()){
  $q = $cart[$r['id']];
  $sum = $q * $r['price'];
  $total += $sum;
  echo "<div class='cart-item'>
    <img src='{$r['image']}' width='80'>
    <div><h4>{$r['name']}</h4><p>".number_format($r['price'])."₫</p>
    <p>Số lượng: <input type='number' name='qty[{$r['id']}]' value='$q' min='1' style='width:60px'></p></div>
  </div>";
}
echo "<h3>Tổng: ".number_format($total)."₫</h3>";
echo "<input type='hidden' name='total' value='$total'>";
echo "<button type='submit'>Thanh toán</button>";
echo "</form>";
?>
</section>
<?php include('includes/footer.php'); ?>
</body></html>
