<?php
include('includes/db.php');
include('includes/header.php');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>SV7 Nike Store</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <section id="products">
    <h2>Sản phẩm nổi bật</h2>
    <div class="product-grid">
      <?php
        $res = $conn->query("SELECT * FROM products");
        while ($row = $res->fetch_assoc()) {
          echo "<div class='product-card'>
            <img src='{$row['image']}' alt='{$row['name']}'>
            <h3>{$row['name']}</h3>
            <p>".number_format($row['price'])."₫</p>
            <form method='POST' action='cart.php'>
              <input type='hidden' name='product_id' value='{$row['id']}'>
              <input type='number' name='qty' value='1' min='1' style='width:60px'>
              <button type='submit'>Mua ngay</button>
            </form>
          </div>";
        }
      ?>
    </div>
  </section>
<?php include('includes/footer.php'); ?>
</body>
</html>
