<?php
session_start();
include('includes/db.php');
if(!isset($_SESSION['user_id'])) header('Location: login.php');

if($_SERVER['REQUEST_METHOD']=='POST'){
  $user_id = $_SESSION['user_id'];
  $total = intval($_POST['total']);
  $address = $conn->real_escape_string($_POST['address'] ?? '');
  $phone = $conn->real_escape_string($_POST['phone'] ?? '');
  $email = $conn->real_escape_string($_POST['email'] ?? '');
  $payment = $conn->real_escape_string($_POST['payment_method'] ?? 'Tiền mặt');

  $conn->query("INSERT INTO orders (user_id,total_price,address,phone,email,payment_method) VALUES ('$user_id','$total','$address','$phone','$email','$payment')");
  $order_id = $conn->insert_id;
  foreach($_POST['qty'] as $pid => $q){
    $pid = intval($pid); $q = intval($q);
    $r = $conn->query("SELECT price FROM products WHERE id=$pid")->fetch_assoc();
    $price = $r['price'];
    $conn->query("INSERT INTO order_items (order_id,product_id,quantity,price) VALUES ($order_id,$pid,$q,$price)");
  }
  unset($_SESSION['cart']);
  echo "<p>Đặt hàng thành công! Mã đơn: $order_id</p>";
  exit;
}
?>
<!doctype html><html><head><meta charset='utf-8'><title>Checkout</title></head><body>
<?php include('includes/header.php'); ?>
<h2>Thông tin giao hàng</h2>
<form method='POST'>
  <label>Email</label><br><input name='email' required><br>
  <label>Phone</label><br><input name='phone' required><br>
  <label>Địa chỉ</label><br><textarea name='address' required></textarea><br>
  <label>Thanh toán bằng</label><br>
  <select name='payment_method'>
    <option>Tiền mặt khi nhận hàng</option>
    <option>Thẻ ngân hàng</option>
  </select><br><br>
  <!-- qty[] and total are posted from cart.php form -->
  <?php
    foreach($_SESSION['cart'] as $pid => $q){
      echo "<input type='hidden' name='qty[$pid]' value='$q'>";
    }
    echo "<input type='hidden' name='total' value='".($_SESSION['cart'] ? array_sum(array_map(function($p,$q){return $p*$q;}, array_column(iterator_to_array($conn->query('SELECT price FROM products WHERE id IN ('.implode(',',array_keys($_SESSION['cart'])).')')), 'price'), $_SESSION['cart'])) : 0 )."'>";
  ?>
  <button type='submit'>Xác nhận mua hàng</button>
</form>
<?php include('includes/footer.php'); ?>
</body></html>
