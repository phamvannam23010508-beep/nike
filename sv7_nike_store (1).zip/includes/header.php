<?php
session_start();
?>
<header>
  <h1>SV7 NIKE STORE</h1>
  <nav>
    <a href="/index.php">Trang chủ</a>
    <a href="/cart.php">Giỏ hàng</a>
    <?php if(isset($_SESSION['user_id'])): ?>
      <a href="/logout.php">Đăng xuất</a>
    <?php else: ?>
      <a href="/login.php">Đăng nhập</a>
      <a href="/register.php">Đăng ký</a>
    <?php endif; ?>
    <a href="/admin/login.php">Admin</a>
  </nav>
</header>
