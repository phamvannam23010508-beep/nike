<?php
// Footer placeholder
?>
<footer><p>&copy; 2025 SV7 Nike Store</p></footer>
