<?php
$host = "localhost";  // change to your RDS endpoint if using RDS
$user = "root";
$pass = "password";
$dbname = "nike_store";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
  die("Kết nối thất bại: " . $conn->connect_error);
}
?>
